<html>
	<head>
	<title>Forgot Password</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
  <body>
  	
  		<header>
			
		</header>
    <form method="post" action="sendmail.php">
      <p>Enter Email Address To Send Password Link</p>
      <input type="text" name="email">
      <input type="submit" name="submit_email">
    </form>
  </body>
</html>
