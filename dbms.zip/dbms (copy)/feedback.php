<!for student Log in>

<!DOCTYPE html>
<?php $username=$_GET ['username'];?>
<html>
<head>
	<title>Feedback</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		
		<header>
			<ul>
				<li><a href='home.php'>Home</a></li>
				<li><a href='search.php'>Search Book</a></li>
				<li><a href='server5.php'>See Issued Books</a></li>
				<li><a href='login.php'>Logout</a></li>
			</ul>
		</header>

		<div class ="header">
			<h2>Write feedback</h2>
		</div>
		
	<form method="post">
		<div class="input-group">
			<label>Feedback</label>
			<input type="text" name="feedback">
		</div>
		
		<div class="input-group">
			<button type="submit" name="feedback1" class="btn">OK</button>
		</div>
	</form>
	
</body>
</html>
<!//for student data entry>
<?php
  
	$db=mysqli_connect('localhost','root','','library');
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $conn->connect_error);
		}
	//if register is clicked
	if(isset($_POST['feedback1']))
	{

		$feedback=mysql_real_escape_string($_POST['feedback']);
	
		{
			$sql="INSERT INTO feedback(username,feedback)
					VALUES ('$username','$feedback')";
			mysqli_query($db,$sql);
			header('location:home.php');
		}
	}
?>
