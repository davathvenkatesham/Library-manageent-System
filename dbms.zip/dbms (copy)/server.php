<!//for student data entry>
<?php
  
	session_start();	
	$username="";
	$email="";
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $conn->connect_error);
		}
	//if register is clicked
	if(isset($_POST['register']))
	{
		$username=mysql_real_escape_string($_POST['username']);
		$name=mysql_real_escape_string($_POST['name']);
		$email=mysql_real_escape_string($_POST['email']);
		$password_1=mysql_real_escape_string($_POST['password_1']);
		$password_2=mysql_real_escape_string($_POST['password_2']);
		$contact=mysql_real_escape_string($_POST['contact']);
		//ensure form fields are filled correctly
		if(empty($username))
		{
			array_push($errors,"Username Required");
		}
		if(empty($name))
		{
			array_push($errors,"Name Required");
		}
		if(empty($email))
		{
			array_push($errors,"Email Required");
		}
		if(empty($contact))
		{
			array_push($errors,"Contact No. Required");
		}
		if(empty($password_1))
		{
			array_push($errors,"Password Required");
		}
		if(($password_1!=$password_2))
		{
			array_push($errors,"Password do not match");
		}
		
		//if there is already username exist.
		
		$query="select * from users where username='$username'";
		$result=mysqli_query($db,$query);
		
		if(mysqli_num_rows($result)==1)
		{
			array_push($errors,"username exist");
		}
		
		$query="select * from users where email='$email'";
		$result=mysqli_query($db,$query);
		
		if(mysqli_num_rows($result)==1)
		{
			array_push($errors,"Email Already  exist");
		}
		// if there is no error,save user to database;
		
		if(count($errors)==0)
		{
			$password=md5($password_1);
			$sql="INSERT INTO users(username,name,contact,email,password)
					VALUES ('$username','$name','$contact','$email','$password')";
			mysqli_query($db,$sql);
			$dpassword =0;
			$sql="INSERT INTO forget(username,dpassword)
					VALUES ('$username','$dpassword')";
			mysqli_query($db,$sql);
			
			$sql="INSERT INTO fine(username,fine)
					VALUES ('$username','0')";
			mysqli_query($db,$sql);
			$_SESSION['username']=$username;
			$_SESSION['success']="YOU ARE NOW LOGGED IN";
			header('location:home.php');//redirect to home page
			
		}
			
	}
	
	//Log user in from log in page 
	if(isset($_POST['Login']))
	{
		$username=mysql_real_escape_string($_POST['username']);
		$password=mysql_real_escape_string($_POST['password']);
		
		if(empty($username))
		{
			array_push($errors,"Username Required");
		}

		if(empty($password))
		{
			array_push($errors,"Password Required");
		}
		if(count($errors)==0)
		{
			$password=md5($password);
			$query="select * from users where username='$username' and password='$password'";
			$result=mysqli_query($db,$query);
			
			if(mysqli_num_rows($result)==1)
			{
				$_SESSION['username']=$username;
				$_SESSION['success']="YOU ARE NOW LOGGED IN";
				header('location:home.php');//redirect to home page
			}
			else
			{
				
				$password=md5(mysql_real_escape_string($_POST['password']));
				$query="select * from forget where username='$username' and dpassword='$password'";
				$result=mysqli_query($db,$query);
				
				if(mysqli_num_rows($result)==1)
				{
					$_SESSION['username']=$username;
					header("Location:forget.php");//redirect to home page
				}
				else
				{
					array_push($errors,"Incorrect Password/OTP");
					
				}
			}

		}
	}
	
	//logout
	if(isset($_GET['logout']))
	{
		session_destroy();
		unset($_SESSION['username']);
		header('location:login.php');
	}
	
?>
