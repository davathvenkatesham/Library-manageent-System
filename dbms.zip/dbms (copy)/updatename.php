<!//for student update contact>


<html>
<head>
	<title>Update Name</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
	<header>
			<h1 style="margin-top:-15px;">Welcome to LiBRARY</h1>
		</header>
	<?php include('updatenameserver.php'); ?>
		<div class ="header">
			<h2>Update Name</h2>
		</div>
		
	<form method="post" action="updatename.php">
	<?php 
	
	include("errors.php"); ?>
		<div class="input-group">
			<label>New Name</label>
			<input type="text" name="name">
		</div>
		<div class="input-group">
			<select name="username">
				<option value="<?php echo substr($_GET['username'],1,-1);?>">Username</option>
			</select>
		</div>
		<div class="input-group">
			<button type="submit" name="update" class="btn">Update</button>
		</div>
	</form>
	
</body>
</html>
