<! connect to database to display all Books>


<!DOCTYPE html>
<html>
<head>
	<title>All books</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
		<header>
			<ul>
				<li><a href='home1.php' >Home</a></li>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Apply Requests</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>


<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $db->connect_error);
		}
	
			$sql="select * 
					from books";

				$result=$db->query($sql);
					
					?>
 
				<table style="background-color:#f1f1c1; width:100% ;">
					<tr>
    					<th>Book-id</th>
    					<th>Title</th> 
    					<th>Author</th>
    					<th>Publisher</th>
    					<th>Category</th>
    					<th>Rental-Price</th>
    					<th>Count</th>
    					<th>Action</th>
    					<th>Action</th>
  					</tr>
					
				<?php
				
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["book_id"]?></td>
        				<td><?php echo  $row["title"]?></td>
        				<td><?php echo  $row["author"]?></td>
        				<td><?php echo  $row["publisher"]?></td>
        				<td><?php echo  $row["category"]?></td>
        				<td><?php echo  $row["price"]?></td>
        				<td><?php echo  $row["count"]?></td>
        				<td><a href="editbook.php?book_id=<?php echo $row["book_id"];?>">Edit Details</a></td>
        				<td><a href="deletebook.php?book_id=<?php echo $row["book_id"];?>">Delete</a></td>
        			</tr>
        			
        		<?php
   				}
				
				?>
			</table>	
		

</body>
</html>
