<!//to register student>
<?php include('server.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>User registration</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
	<style>
	body
		{
			border: 10px solid #5F9EAB;
			border-radius:	10px 10px 10px 10px;
		}
	</style>
	
	
</head>
<body>
	
		<header>
			<h1 style="margin-top:-15px;">Welcome to LiBRARY</h1>
			
		</header>
	
		<img class="image" src="https://upload.wikimedia.org/wikipedia/en/b/b7/Mnit_logo.png" style="width:200px;height:200px;" alt="MNIT LOGO">
		
		<img class="image2" src="https://img.freepik.com/free-vector/library-bookshelf_23-2147502675.jpg?size=338&ext=jpg" alt="Library Image" style="width:200px;height:200px;" align=right>
		
		<div class ="header" style="margin-top:-205px;">
			<h2>Student Registration Form</h2>
		</div>
		
	<form method="post" action="register.php" >
	<?php include('errors.php'); ?>
		<div class="input-group">
			<label>Username/Student-Id</label>
			<input type="text" name="username" value="<?php echo $username;?>" >
		</div>
		
		<div class="input-group">
			<label>Name</label>
			<input type="text" name="name">
		</div>
		
		<div class="input-group">
			<label>Email</label>
			<input type="text" name="email" value="<?php echo $email ;?>" >
		</div>
		<div class="input-group">
			<label>Contact</label>
			<input type="int" name="contact" value="<?php echo $email ;?>" >
		</div>
		
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password_1">
		</div>
		
		<div class="input-group">
			<label>Confirm Password</label>
			<input type="password" name="password_2">
		</div>
		
		<div class="input-group">
			<button type="submit" name="register" class="btn">Register</button>
		</div>
		<p> Already a member ? <a href="login.php">Log in</a>
		</p>
	</form>
</body>
</html>
