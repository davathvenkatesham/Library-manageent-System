<!connect to database to search users>

<?php include('sserver2.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Accepted Orders</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
		<header>
			<ul>
				<li><a href='home2.php'>Home</a></li>
				<li><a href='orders2.php'>New Orders</a></li>
				<li><a href='login2.php'>Logout</a></li>
			</ul>
		</header>

<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if($db->connect_error)
	{
		die("Connection Failed:" . $db->connect_error);
	}
	
		$username=$_SESSION['username'];
		$sql="select *
					from accepted where username='$username'";
					
				$result=$db->query($sql);
				?>
				<table style="background-color:#f1f1c1; width:100% ;">
					<tr>
    					<th>Order-id</th>
    					<th>Description</th>
    					<th>Action</th>
  					</tr>
				
				<?php
					while($row = $result->fetch_assoc())
					{
						$od=$row["order_no"];
					$sql2="select *
					from orders where order_no='$od'";
					$result2=$db->query($sql2);
					$row2 = $result2->fetch_assoc()
					?>
					<tr>
        				<td><?php echo  $row["order_no"]; ?> </td>
        				<td><?php echo  $row2["description"]; ?></td>
        				<td><a href="rejectorder.php?orderno=<?php echo $row["order_no"];?>">Reject order</a></td>
        			</tr>
        			
        		<?php
   				}
				?>
			</table>	
</body>
</html>
