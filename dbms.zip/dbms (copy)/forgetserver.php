<!//for student forget password>
<?php

	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $conn->connect_error);
		}
	//if register is clicked
	if(isset($_POST['reset']))
	{
		
		$password_1=mysql_real_escape_string($_POST['password_1']);
		$password_2=mysql_real_escape_string($_POST['password_2']);
		
		if(empty($password_1))
		{
			array_push($errors,"Password Required");
		}
		if(($password_1!=$password_2))
		{
			array_push($errors,"Password do not match");
		}
		
		if(count($errors)==0)
		{
	
			$password=md5($password_1);
			$sql="update users 
					set password ='$password' 
					where username='$username'";
			mysqli_query($db,$sql);
			echo "Password reset Successful.\n Now log in with new Password\n";
			
		}
	}

?>
