<!//for student update contact>


<html>
<head>
	<title>Update Email</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
	<header>
			<h1 style="margin-top:-15px;">Welcome to LiBRARY</h1>
		</header>
	<?php include('updateemailserver.php'); ?>
		<div class ="header">
			<h2>Update Email</h2>
		</div>
		
	<form method="post" action="updateemail.php">
	<?php 
	
	include("errors.php"); ?>
		<div class="input-group">
			<label>New Email</label>
			<input type="text" name="email">
		</div>
		<div class="input-group">
			<select name="username">
				<option value="<?php echo substr($_GET['username'],1,-1);?>">Username</option>
			</select>
		</div>
		<div class="input-group">
			<button type="submit" name="update" class="btn">Update</button>
		</div>
	</form>
	
</body>
</html>
