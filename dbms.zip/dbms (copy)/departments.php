<?php include('header.php'); ?>
<?php include('navbar.php'); ?>

		<table style="border: 2px solid black; margin-top:40px; padding: 10px; text-align: center; text-size:22;">

			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='archi'">Architecture & Planning</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='chemical'">Chemical Engineering</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='chemistry'">Chemistry</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='ce'">Civil Engineering</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='cse'">Computer Science & Engineering</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='ece'">Electronics & Comm. Engineering</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='ee'">Electrical Engineering</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='hst'">Humanities & Social Sc.</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='mngt'">Management Studies</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='maths'">Mathematics</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='meta'">Metallurgical & Material Engineering</a></td>
			</tr>
			<tr style="border: 2px solid black;">
				<td><a href="cse.php?id='physics'">Physics</a></td>
			</tr>
		</table>

