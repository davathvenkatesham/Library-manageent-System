<!for student Log in>
<!DOCTYPE html>
<html>
<head>
	<title>Reset Password</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
	
		<header>
			<h1 style="margin-top:-15px;">Welcome to LiBRARY</h1>
		</header>
		<?php include('server.php'); ?>
	<?php $username=$_SESSION['username'];?>
	<?php include('forgetserver.php'); ?>
		<div class ="header">
			<h2>Reset Password</h2>
		</div>
		
	<form method="post" action="forget.php">
	<?php include("errors.php"); ?>
		
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password_1">
		</div>
		<div class="input-group">
			<label>Confirm Password</label>
			<input type="password" name="password_2">
		</div>
		
		<div class="input-group">
			<button type="submit" name="reset" class="btn">Reset</button>
			<button type="submit" name="back" class="btn">Back</button>
		</div>
	</form>
	
	<! Go back to index page>
		<?php
		if(isset($_POST['back']))
		{
			header('location:login.php');
		}
		?>
		
	
</body>
</html>
