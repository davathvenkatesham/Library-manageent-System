<!connect to database to search users>
<html>
<head>
</head>
<body>
<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if($db->connect_error)
	{
		die("Connection Failed:" . $db->connect_error);
	}
	if(isset($_POST['search2']))
	{
		$searchby=mysql_real_escape_string($_POST['searchby']);
		$search_by=mysql_real_escape_string($_POST['search_by']);
		if(!empty($searchby))
		{
			if($search_by=='student_id')
			{
				$sql="select * 
					from users
					where username='$searchby'";
					
				$result=$db->query($sql);
				if($result->num_rows > 0)
				{
					?>
					
					<table style="width:100% ; background-color: #f1f1c1;">
					<tr>
    					<th>User-id</th>
    					<th>Name</th> 
    					<th>Email</th>
    					<th>Contact</th>
    					<th>Action</th>
    					<th>Action</th>
  					</tr>
					
					<?php
					while($row = $result->fetch_assoc()) 
					{
						?>
							
						<tr>
        				<td><a href="userprofile.php?username=<?php echo  $row["username"]?>"><?php echo  $row["username"]?></a></td>
        				<td><?php echo  $row["name"] ?> </td>
        				<td><?php echo  $row["email"] ?></td>
        				<td><?php echo  $row["contact"] ?></td>
        				<td><a href="contactuser.php?username=<?php echo $row["email"];?>">Contact</a></td>
        				<td><a href="deleteuser.php?username=<?php echo $row["username"];?>">Delete</a></td>
        				</tr>
        				
        			<?php	
   				}
   				?>
   				
   				</table>
   				<?php
				}
				else
				{
					echo "no result found";
				}
			}
			
			else
			{
				$sql="select * 
					from users
					where name='$searchby'";
					
				$result=$db->query($sql);
				if($result->num_rows > 0)
				{
					?>
					
					<table style="width:100%">
					<tr>
    					<th>User-id</th>
    					<th>Name</th> 
    					<th>Email</th>
    					<th>Contact</th>
  					</tr>
					
					<?php
					while($row = $result->fetch_assoc()) 
					{
						?>
							
						<tr>
        				<td><?php echo  $row["username"]?></td>
        				<td><?php echo  $row["name"] ?> </td>
        				<td><?php echo  $row["email"] ?></td>
        				<td><?php echo  $row["contact"] ?></td>
        				</tr>
        				
        			<?php	
   				}
   				?>
   				
   				</table>
   				<?php
				}
				else
				{
					echo "no result found";
				}
		}
		}
		else
		{
			array_push($errors,"Please fill the field");
		}
	}
?>
</body>
</html>
