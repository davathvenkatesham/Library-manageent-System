<?php
$db=mysqli_connect('localhost','root','','library');
if ($db->connect_error)
	{
    	die("Connection failed: " . $conn->connect_error);
	}
	$query="select * from issued";
	$result=$db->query($sql);
	$row = $result->fetch_assoc();
	$fine=$row["fine"];
?>
