<! to search Book include server3 to search book in database By Admin>

<!DOCTYPE html>
<html>
<head>
	<title>Edit book Detail</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
		<header>
			<ul>
				<li><a href='home1.php' >Home</a></li>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
		
		<?php include('editbookserver.php'); ?>	
		<div class ="header">
			<h2>Edit Book Details in the Library</h2>
		</div>
		
	<form method="post" action="editbook.php">
	<?php include("errors.php"); ?>
		<div>
				<p>Edit</p>
			</div>
			
			<select name="edit_by">
				<option value="title">Title</option>
				<option value="author">Author</option>
				<option value="publisher">Publisher</option>
				<option value="category">Category</option>
				<option value="count">Count</option>
			</select>
			
			<div class="input-group">
			<input type="text" name="editby" >
		</div>
		<div class="input-group">
			<select name="bookid" >
				<option value="<?php echo $_GET['book_id'];?>">Book Id</option>
			</Select>
		</div>
		
		<div class="input-group">
			<button type="submit" name="edit" class="btn">Edit</button>
		</div>
		<p>  <a href="home1.php">Back to Home</a>
		</p>
		
	</form>
</body>
</html>

