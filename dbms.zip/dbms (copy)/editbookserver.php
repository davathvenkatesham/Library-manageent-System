<! connect to database to search Books>
<html>
<head>
	
</head>
<body>
<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $db->connect_error);
		}
	
	//if search is clicked
	if(isset($_POST['edit']))
	{
		$bookid=mysql_real_escape_string($_POST['bookid']);
		$searchby=mysql_real_escape_string($_POST['editby']);
		$search_by=mysql_real_escape_string($_POST['edit_by']);
		
		//ensure atleast one field is filled correctly
		if(!empty($searchby))
		{
			if($search_by=='title')
			{
				$sql="update books 
					  set title='$searchby'
					where book_id='$bookid'";
					
				mysqli_query($db,$sql);
				echo "Details Updated Successfully\n";
			}
			else if($search_by=='author')
			{
				$sql="update books 
					  set author='$searchby'
					where book_id='$bookid'";
					
				mysqli_query($db,$sql);
				echo "Details Updated Successfully\n";
			}
			else if($search_by=='publisher')
			{
				$sql="update books 
					  set publisher='$searchby'
					where book_id='$bookid'";
					
				mysqli_query($db,$sql);
				echo "Details Updated Successfully\n";
			}
			else if($search_by=='category')
			{
				$sql="update books 
					  set category='$searchby'
					where book_id='$bookid'";
					
				mysqli_query($db,$sql);
				echo "Details Updated Successfully\n";
			}
			else
			{
				$sql="update books 
					  set count='$searchby'
					where book_id='$bookid'";
					
				mysqli_query($db,$sql);
				echo "Details Updated Successfully\n";
			}
		}
		else
		{
			array_push($errors,"Enter the New Data");
		}
	}
?>
	
</body>
</html>
