<html>
	<head>
		<title>About Us</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
	
		<header>
			<h1 style="margin-top:-15px;">About Us</h1>
		</header>
		<table>
			<tr>
				<th>Name</th>
				<th>Id</th>
				<th>Email</th>
			</tr>
			<tr>
				<td>Parvat Jakhar</td>
				<td>2016UCP1699</td>
				<td>parvatjakhar@gmail.com</td>
			</tr>
			<tr>
				<td>Girish Kumar</td>
				<td>2016UCP1706</td>
				<td>2016ucp1706@mnit.ac.in</td>
			</tr>
		</table>
		<p><a href='index.php'>Back</a>
		</p>	
	</body>
</html>
