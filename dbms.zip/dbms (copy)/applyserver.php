<!connect to apply for Books Books>
<?php
	include('server.php');?>
<html>
<head>
	<title>Applied Successfully</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
			<ul>
				<li><a href='home.php'>Home</a></li>
				<li><a href='search.php'>Search Book</a></li>
				<li><a href='server5.php?username=<?php echo $_SESSION['username'];?>'>See Issued Books</a></li>
				<li><a href='login.php'>Logout</a></li>
			</ul>
		</header>

<?php
	
	
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if($db->connect_error)
	{
		die("Connection Failed:" . $db->connect_error);
	}
	if(isset($_GET['book_id']))
	{
		$bookid=$_GET['book_id'];
		$username=$_SESSION['username'];
		$date=date("Y-m-d");

				$sql="INSERT INTO applied(username,book_id,applydate)
						VALUES ('$username','$bookid','$date')";
						
					mysqli_query($db,$sql);
		?>
					<p> <?php echo "Applied Successfully";?></p>
					<p><a href="search.php">Back</a></p>
	
	<?php
		
	}
?>
</body>
</html>
