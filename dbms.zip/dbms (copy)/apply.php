<! to apply for books library>

<html>
	<head>
		<title>Apply For Books</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
	
		<header>
			<ul>
				<li><a href='home.php'>Home</a></li>
				<li><a href='search.php'>Search Book</a></li>
				<li><a href='apply.php'>Apply For Book</a></li>
				<li><a href='login.php'>Logout</a></li>
			</ul>
		</header>
	
	<?php include('applyserver.php'); ?>
	
		<div class ="header">
			<h2>Apply For Books</h2>
		</div>
		<form method="post" action="apply.php">
			<?php include("errors.php"); ?>
		
		<p>  <a href="search.php">Search Book</a>
		</p>	
		
		<p>  <a href="home.php">Back to Home</a>
		</p>
		</form>
	</body>
</html>
