<!for student Log in>
<?php include('server.php'); ?>

<!DOCTYPE html>
<html>
<head>
	<title>OTP</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
		
		<header>
			<h1 style="margin-top:-15px;">Welcome to LiBRARY</h1>
			
		</header>
		
		<div class ="header">
			<h2>Enter Otp</h2>
		</div>
		
	<form method="post" action="loginotp.php">
	<?php include("errors.php"); ?>
		<div class="input-group">
			<select name="username" >
				<option value="<?php echo $_GET['username'];?>"></option>
			</Select>
		</div>
		
		<div class="input-group">
			<label>OTP</label>
			<input type="password" name="password">
		</div>
		
		<div class="input-group">
			<button type="submit" name="Login" class="btn">Submit</button>
		</div>
		
	</form>
	
	
</body>
</html>
