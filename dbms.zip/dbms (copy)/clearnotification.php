<! connect to database to return Books>
<html>
<head>
	<title>Clear Notifications</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
			<ul>
				<li><a href='home.php'>Home</a></li>
				<li><a href='search.php'>Search Book</a></li>
				<li><a href='server5.php'>See Issued Books</a></li>
				<li><a href='login.php'>Logout</a></li>
			</ul>
		</header>	
	
<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $db->connect_error);
		}
	
	
	{
				$username=$_GET['username'];
				$sql="delete
					from notification
					where username='$username'";
					
				if(mysqli_query($db,$sql))
					echo "No New Notificatuons";
				else
				{
					echo "Error Occured User Not Deleted ";
				}
	}
?>
</body>
</html>
