<! to search Book include server3 to search book in database By Admin>

<!DOCTYPE html>
<html>
<head>
	<title>search book</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
		<header>
			<ul>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='return.php'>Return Book</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
<?php include('returnserver.php'); ?>	
		<div class ="header">
			<h2>Return Book in the Library</h2>
		</div>
		
	<form method="post" action="return.php">
		<?php include("errors.php"); ?>
	
		<div>
				<p>Return By</p>
			</div>
			
			<select name="return_by">
				<option value="book_id">Book-id</option>

			</select>
			
			<div class="input-group">
			<input type="text" name="returnby" >
		</div>
		
	
		<div class="input-group">
			<button type="submit" name="return" class="btn">Return</button>
		</div>
		<p>  <a href="home1.php">Back to Home</a>
		</p>
		
	</form>
</body>
</html>

