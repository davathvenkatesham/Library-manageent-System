<!connect to database to search users>

<?php include('sserver2.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Orders</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
		<header>
			<ul>
				<li><a href='home2.php'>Home</a></li>
				<li><a href='acceptedorders.php?username=<?php echo $_SESSION['username'];?>'>Accepted Orders</a></li>
				<li><a href='login2.php'>Logout</a></li>
			</ul>
		</header>

<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if($db->connect_error)
	{
		die("Connection Failed:" . $db->connect_error);
	}
	
	
		$sql="select *
					from orders";
					
				$result=$db->query($sql);
				?>
				<table style="background-color:#f1f1c1; width:100% ;">
					<tr>
    					<th>Order-id</th>
    					<th>Description</th>
    					<th>Date</th>
    					<th>Action</th>
  					</tr>
				
				<?php
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["order_no"] ?> </td>
        				<td><?php echo  $row["description"] ?></td>
        				<td><?php echo  $row["date"] ?></td>
        				<td><a href="acceptorder.php?orderno=<?php echo $row["order_no"];?>">Accept order</a></td>
        			</tr>
        			
        		<?php
   				}
				?>
			</table>	
			
</body>
</html>
