<!user home page>
<?php include('server.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
		
		<header>
			<ul>
				<li><a href='profile.php?username=<?php echo $_SESSION['username'];?>'>Update Profile</a></li>
				<li><a href='search.php'>Search Book</a></li>
				<li><a href="server5.php?username=<?php echo $_SESSION['username'];?>">See Issued Books</a></li>
				<li><a href='notification.php?username=<?php echo $_SESSION['username'];?>'>Notifications</a></li>
				<li><a href='fine.php?username=<?php echo $_SESSION['username'];?>'>My Fines</a></li>
				<li><a href='feedback.php?username=<?php echo $_SESSION['username'];?>'>Give Feedback</a></li>
				
				<li><a href='login.php'>Logout</a></li>
			</ul>
		</header>
		
		<img class="image" src="https://upload.wikimedia.org/wikipedia/en/b/b7/Mnit_logo.png" style="width:200px;height:200px;" alt="MNIT LOGO">
		
		<img class="image2" src="https://img.freepik.com/free-vector/library-bookshelf_23-2147502675.jpg?size=338&ext=jpg" alt="Library Image" style="width:200px;height:200px;" align=right>

		
		
		
		<?php 
		$db=mysqli_connect('localhost','root','','library');
		?>
		<table style="background-color:#f1f1c1; width:50% ;margin-top:-205px; margin-left: auto;
margin-right: auto;">
			<?php
					$username=$_SESSION['username'];
					$query="select * from users where username='$username'";
					$result=mysqli_query($db,$query);
					$row = $result->fetch_assoc()
					?>
					<tr>
        				<td>User-Id</td>
        				<td><?php echo  $row["username"];?></td>
        			</tr>
        			<tr>
        				<td>Name</td>
        				<td><?php echo  $row["name"];?></td>
        			</tr>
        			<tr>
        				<td>Email</td>
        				<td><?php echo  $row["email"];?></td>
        			</tr>
        			<tr>
        				<td>Contact</td>
        				<td><?php echo  $row["contact"];?></td>
        			</tr>
			</table>	

		
		<div class="content">
			<?php if(isset($_SESSION['success'])):?>
				<div class="error success">
					<h3>
						<?php
							echo $_SESSION["success"];
							unset($_SESSION["success"]); 
						?>
					</h3>
				</div>
			<?php endif ?>
			<?php if(isset($_SESSION['username'])):?>
				
			<?php endif ?>
			
		</div>
		

</body>
</html>
