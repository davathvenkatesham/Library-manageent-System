<! to see issued books>

<html>
	<head>
		<title>See Issued Books</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
	
		<header>
			<ul>
				<li><a href='home.php'>Home</a></li>
				<li><a href='search.php'>Search Book</a></li>
				
				<li><a href='server5.php'>See Issued Books</a></li>
				<li><a href='login.php'>Logout</a></li>
			</ul>
		</header>
	
	<?php include('server5.php'); ?>
	
		<div class ="header">
			<h2>See Issued Books</h2>
		</div>
		<form method="post" action="server5.php">
			<?php include("errors.php"); ?>
			
			<label>Student-id</label>
			<div class="input-group">
			<input type="text" name="username" >
		</div>
			
		<div class="input-group">
			<button type="submit" name="issued" class="btn">See</button>
		</div>
		<p>  <a href="home.php">Back to Home</a>
		</p>
		</form>
	</body>
</html>
