		
		
<?php

if(isset($_POST['place']))
{
		$db=mysqli_connect('localhost','root','','library');
		if($db->connect_error)
			{
				die("Connection Failed:" . $db->connect_error);
			}
		$username=mysql_real_escape_string($_POST['username']);
		$desc=mysql_real_escape_string($_POST['name']);
			
		$query="update orders set description='$desc' where order_no='$username'";
		if(mysqli_query($db,$query))
		{
			echo "Order Edited Successfully";
		}
}
?>







