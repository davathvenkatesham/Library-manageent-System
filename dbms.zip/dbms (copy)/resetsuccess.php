<!for student Log in>
<?php include('server.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>User Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
		
		<header>
			<h1 style="margin-top:-15px;">Welcome to LiBRARY</h1>
			
		</header>

		<div class ="header">
			<h2>Student Login</h2>
		</div>
		
	<form method="post" action="login.php">
	<?php include("errors.php"); ?>
		<div class="input-group">
			<label>Username</label>
			<input type="text" name="username">
		</div>
		
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		
		<div class="input-group">
			<button type="submit" name="Login" class="btn">Login</button>
			<button type="submit" name="back" class="btn">Back</button>
		</div>
		<p> <a href="reset_pass.php">Forgot Password</a>
		</p>
		<p> Not a member ? <a href="register.php">Sign Up</a>
		</p>
		
	</form>

</body>
</html>
