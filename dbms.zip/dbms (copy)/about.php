<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">	
			<?php include('head.php'); ?>
				
				<div class="text_content">
					
		
	
	<table class="staff" >
	<thead><tr><th colspan="3"  style="text-align: center;"><h3>LIBRARY STAFF</h3></th></tr></thead>
	<tbody>
	<tr>
	<td colspan="3"></td>
	</tr>
	<tr>
	<td>Mr. Deep Singh<br />Librarian </td>
	</tr>
	</tbody>
	</table>
	<table class="staff" >
	<thead><tr><th colspan="3"  style="text-align: center;"><h3>Developers</h3></th></tr></thead>
	<tbody>
	<tr>
	<td colspan="3"></td>
	</tr>
	<tr>
	<td>Mr. Parvat Jakhar</td>
	</tr>
	<tr>
	<td>2016UCP1699</td>
	</tr>
	
	<tr>
	<td>Mr. Girish kumar</td>
	</tr>
	<tr>
	<td>2016UCP1699</td>
	</tr>
	</tbody>
	</table>
					</div>
					</div>
			
		</div>
    </div>
<?php include('footer.php') ?>
