<!//for student update contact>
<?php
		if(isset($_POST['update']))
		{
		
		$db=mysqli_connect('localhost','root','','library');
		if ($db->connect_error)
	 	{
    		die("Connection failed: " . $conn->connect_error);
		}

		$password=mysql_real_escape_string($_POST['password']);
		$password1=mysql_real_escape_string($_POST['password_1']);
		$password2=mysql_real_escape_string($_POST['password_2']);
		$username=$_GET['username'];
		$errors=array();
		if(empty($password))
		{
			array_push($errors,"Enter Old Password");
		}
		if(empty($password1))
		{
			array_push($errors,"Password Required");
		}
		if(($password1!=$password2))
		{
			array_push($errors,"Password do not match");
		}
		if(count($errors)==0)
		{
			echo $password1;
			$password=md5($password1);
			$sql="update users set password ='$password' where username='$username'";
			mysqli_query($db,$sql);
			echo "Password reset Successful.\n Now log in with new Password\n";
			header('location:login.php');//redirect to login page
		}
		}
		?>
<html>
<head>
	<title>Update Password</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
	
	
	<header>
			<h1 style="margin-top:-15px;">Welcome to LiBRARY</h1>
			
		</header>

		<div class ="header">
			<h2>Update Password</h2>
		</div>
		
	<form method="post" action="updatepassword.php">
	<?php include("errors.php"); ?>
		<div class="input-group">
			<label>Current Password</label>
			<input type="password" name="password">
		</div>
		
		<div class="input-group">
			<label>New Password</label>
			<input type="password" name="password_1">
		</div>
		<div class="input-group">
			<label>Confirm New Password</label>
			<input type="password" name="password_2">
		</div>
		<div class="input-group">
			<button type="submit" name="update" class="btn">Update</button>
		</div>
		<p>
			<a href="profile.php?username=<?php echo $username;?>">Back</a>
		</p>

	</form>
	
</body>
</html>
