<html>
	<head>
	<title>Contact User</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  	
  		<header>
		
<?php


if(isset($_POST['submit']))
{
$email=mysql_real_escape_string($_POST['username']);
$message=mysql_real_escape_string($_POST['message']);
require_once "Mail.php"; 
$from = "parvatjakhar@gmail.com"; 
$to = $email; 
$host = "ssl://smtp.gmail.com"; 
$port = "465"; 
$username = 'parvatjakhar@gmail.com';
 $password = 'Parvat@1';
 $subject = "Message From Admin,Library"; 
 $body = $message."\nRegards \n MNIT LIBRARY"; 
 $headers = array ('From' => $from, 'To' => $to,'Subject' => $subject);
  $smtp = Mail::factory('smtp', array ('host' => $host, 'port' => $port, 'auth' => true, 'username' => $username, 'password' => $password));
  $mail = $smtp->send($to, $headers, $body); 
  if (PEAR::isError($mail)) 
  {
  		echo($mail->getMessage()); 
  }
  else 
  {

  		?>
  		<p style="padding:10px;
		font-size:15px;
		color:white;
		background:#5F9EAB;
		border:none;
		border-radius:5px;">
  		<?php echo("Message sent successfully!\n");
  		
  		?>
  		>
  		
  		<?php
  		
  }

}

?>

  </header>
    <form method="post" action="contactuser.php">
		<div class="input-group">
			<label>Enter Message</label>
			<input type="text" name="message">
		</div>
		<div class="input-group">
			<select name="username">
				<option value="<?php echo $_GET['username'];?>">Email</option>
			</select>
		</div>
     <button type="submit" name="submit" class="btn">Send</button>
     <p>  <a href="home1.php">Back</a>
		</p>
    </form>
  </body>
</html>

