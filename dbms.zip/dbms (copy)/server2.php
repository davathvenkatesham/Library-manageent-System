
<!to enter new book details>

<?php
	session_start();	
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $conn->connect_error);
		}
	//if register is clicked
	if(isset($_POST['newbook']))
	{
		$bookid=mysql_real_escape_string($_POST['book_id']);
		$author=mysql_real_escape_string($_POST['author']);
		$title=mysql_real_escape_string($_POST['title']);
		$publisher=mysql_real_escape_string($_POST['publisher']);
		$cat=mysql_real_escape_string($_POST['category']);
		$price=mysql_real_escape_string($_POST['price']);
		$status=mysql_real_escape_string($_POST['count']);
		//ensure form fields are filled correctly
		if(empty($bookid))
		{
			array_push($errors,"Please fill all details");
		}
		if(empty($author))
		{
			array_push($errors,"Please fill all details");
		}
		if(empty($title))
		{
			array_push($errors,"Please fill all details");
		}
		if(empty($publisher))
		{
			array_push($errors,"Please fill all details");
		}
		if(empty($cat))
		{
			array_push($errors,"Please fill all details");
		}
		if(empty($price))
		{
			array_push($errors,"Please fill all details");
		}
		if(empty($status))
		{
			array_push($errors,"Please fill all details");
		}
		
		// if there is no error,save user to database;
			
		if(count($errors)==0)
		{
			$sql="INSERT INTO books(book_id,title,author,publisher,category,price,count)
					VALUES ('$bookid','$title','$author','$publisher','$cat','$price','$status')";
					if(mysqli_query($db,$sql))
					{
						echo "Entered";
					}
					else
						echo "Error While Addding Books In The Library";
					
		}
		
	}
	
?>
