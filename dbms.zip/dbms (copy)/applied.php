<! connect to database to see applied Books>
<html>
<head>
	<title>Applications</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
			<ul>
				<li><a href='home1.php' >Home</a></li>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Issue Requests</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
	
	
<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $db->connect_error);
		}

				$sql="select * 
					from applied natural join books
					";
					
				$result=$db->query($sql);
				if($result->num_rows > 0)
				{
				?>
				<table style="width:100%;background-color:#f1f1c1;">
					<tr>
    					<th>Book-id</th>
    					<th>Book-Title</th>
    					<th>Available Copies</th>
 						<th>Student-Id</th>
 						<th>Apply-date</th>
 						<th>Action</th>
 						<th>Action</th>
  					</tr>
				
				<?php
				
					while($row = $result->fetch_assoc()) 
					{
					?>
					
					<tr>
        				<td><?php echo  $row["book_id"]?></td>
        				<td><?php echo  $row["title"]?></td>
        				<td><?php echo  $row["count"]?></td>
        				<td><?php echo  $row["username"]?></td>
        				<td><?php echo  $row["applydate"]?></td>
						<td><a href="issueserver.php?book_id=<?php echo $row["book_id"];?>&amp;username=<?php echo  $row["username"];?>">Issue</a></td>
						<td><a href="deleterequest.php?book_id=<?php echo $row["book_id"];?>&amp;username=<?php echo  $row["username"];?>">Delete</a></td>
        			</tr>
        			
        		<?php
   				}
				
				?>
			</table>	

<?php
				}
				else
				{
					echo "No Pending Application";
				}

?>

</body>
</html>
