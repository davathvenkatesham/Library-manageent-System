<?php include('server.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Library</title>
	<link rel="stylesheet" type="text/css" href="style.css">

	
</head>
<body>
		<header>
			<h1 style="margin-top:-15px;">Welcome to LiBRARY</h1>
			
		</header>
		<img class="image" src="https://upload.wikimedia.org/wikipedia/en/b/b7/Mnit_logo.png" style="width:200px;height:200px;" alt="MNIT LOGO">
		
		<img class="image2" src="https://img.freepik.com/free-vector/library-bookshelf_23-2147502675.jpg?size=338&ext=jpg" alt="Library Image" style="width:200px;height:200px;" align=right>
		
		
		<div class ="header" style="margin-top:-150px;">
			<h2 >Choose Account</h2>
		</div>
		
		<form method="post" action="index1.php">
		
		<div class="input-group">
			<button type="submit" name="admin" class="btn">Admin</button>
		</div>
		<div class="input-group">
			<button type="submit" name="student" class="btn">Student</button>
		</div>
		<div class="input-group">
			<button type="submit" name="supplier" class="btn">Supplier</button>
		</div>
		<p> <a href="index.php">Back</a>
		</p>
  		
		</form>
		
		<?php
		//log in as admin or student.
		
		if(isset($_POST['student']))
		{
			header('location:login.php');
		}
		if(isset($_POST['admin']))
		{
			header('location:login1.php');
		}
		if(isset($_POST['supplier']))
		{
			header('location:login2.php');
		}
		?>

</body>
</html>
