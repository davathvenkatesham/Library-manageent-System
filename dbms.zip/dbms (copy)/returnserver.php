<! connect to database to return Books>
<html>
<head>
	<title>Returned</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
			<ul>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Applied Requests</a></li>
				<li><a href='return.php'>Return Book</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>	
	
<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $db->connect_error);
		}
	
	//if search is clicked
	if(isset($_POST['return']))
	{
		
		$returnby=mysql_real_escape_string($_POST['returnby']);
		$return_by=mysql_real_escape_string($_POST['return_by']);
		

				$sql="delete
					from issued
					where book_id='$returnby'";
				
				
					
				mysqli_query($db,$sql);
				echo "returned";
	}
	else
	{
				$username=$_GET['username'];
				$bookid=$_GET['book_id'];
				
				
					$sql="select *
					from issued
					where book_id='$bookid' and username='$username'";
					$result=$db->query($sql);
					$row = $result->fetch_assoc();
					$returndate=$row["returndate"];
					
					
				
				$sql="delete
					from issued
					where book_id='$bookid' and username='$username'";
				mysqli_query($db,$sql);
				
				$sql="select count from books where book_id=$bookid";
				$result=$db->query($sql);
				$row = $result->fetch_assoc();
				$count=$row["count"];
				$count++;
				
				$sql="update books 
					set count='$count'
					where book_id='$bookid'";
					mysqli_query($db,$sql);
					
					
					$curDate=date("Y-m-d");
					$daysLeft = (strtotime($curDate) - strtotime($returndate));
					$days = $daysLeft/(60 * 60 * 24);
				
					
				if($days > 0)
				{
					
					$fine=$days*10;
					$sql="UPDATE fine set fine=fine+'$fine'
					 		where username='$username'";
					mysqli_query($db,$sql);
					
					
					
					$sql="select * from fine where username=$username";
					$result=$db->query($sql);
					$row = $result->fetch_assoc();
					$fine=$row['fine'];
					
					
					$message='Your Have Total Due Fines Of Rupees '.$fine.'Kindly Pay ASAP';
					date_default_timezone_set('Asia/Kolkata');
					$time=date("h:i:a");
					$date=date("Y-m-d");
					$sql="INSERT INTO notification(username,notification,date,time)
							VALUES ('$username','$message','$date','$time')";	
							mysqli_query($db,$sql);
					
				}
				$message='Your Book with book-id '.$bookid.' Have Been Returned Successfully ';
					date_default_timezone_set('Asia/Kolkata');
					$time=date("h:i:a");
					$date=date("Y-m-d");
					$sql="INSERT INTO notification(username,notification,date,time)
							VALUES ('$username','$message','$date','$time')";	
							mysqli_query($db,$sql);
				
				echo "Returned Successfully";
	}
?>
</body>
</html>
