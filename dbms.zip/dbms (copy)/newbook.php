<! new book entry>

<!DOCTYPE html>
<html>
<head>
	<title>New Book entry</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
		<header>
			<ul>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='return.php'>Return Book</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
		
		<?php include('server2.php'); ?>
		
		<div class ="header" style="margin-top:-2px;">
			<h2>New Book Entry </h2>
		</div>
		
	<form method="post" action="newbook.php">
	<?php include('errors.php'); ?>
		<div class="input-group">
			<label>Book-Id</label>
			<input type="int" name="book_id" >
		</div>
		
		<div class="input-group">
			<label>Book-Title</label>
			<input type="text" name="title" >
		</div>
		
		<div class="input-group">
			<label>Author</label>
			<input type="text" name="author" >
		</div>
		
		<div class="input-group">
			<label>Publisher</label>
			<input type="text" name="publisher" >
		</div>
		
		<div class="input-group">
			<label>Category</label>
			<input type="text" name="category" >
		</div>
		
		<div class="input-group">
			<label>Rental Price</label>
			<input type="int" name="price" >
		</div>
		
		<div class="input-group">
			<label>Count</label>
			<input type="text" name="count" >
		</div>
		
		<div class="input-group">
			<button type="submit" name="newbook" class="btn">Enter</button>
		</div>
		<p>  <a href="home1.php">Back to Home</a>
		</p>
		
	</form>
</body>
</html>
