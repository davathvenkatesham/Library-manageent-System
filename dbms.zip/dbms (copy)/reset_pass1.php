<html>
	<head>
	<title>Forgot Password</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  	
  		<header>
		
<?php
$servername='localhost';
$username='root';
$password='';
$dbname = 'library';
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn)
{
die('Could not Connect My Sql:' .mysql_error());
}

session_start();


if(isset($_POST['submit']))
{
$email = $_POST['email'];
$result = mysqli_query($conn,"SELECT * FROM users where email='$email'");
$row = mysqli_fetch_assoc($result);
$fetch_email=$row['email'];
$password1=$row['password'];
if($email==$fetch_email) 
{

require_once "Mail.php"; 
$from = "parvatjakhar@gmail.com"; 
$to = '2016ucp1699@mnit.ac.in'; 
$host = "ssl://smtp.gmail.com"; 
$port = "465"; 
$username = 'parvatjakhar@gmail.com';
 $password = 'Parvat@1'; 
 $subject = "Forgot Password"; 
 $body = "Your Old Password is ".$password1."Sign in Again Using this Passsword\n Regards \n MNIT LIBRARY"; 
 $headers = array ('From' => $from, 'To' => $to,'Subject' => $subject);
  $smtp = Mail::factory('smtp', array ('host' => $host, 'port' => $port, 'auth' => true, 'username' => $username, 'password' => $password)); 
  $mail = $smtp->send($to, $headers, $body); 
  if (PEAR::isError($mail)) 
  { 
  		echo($mail->getMessage()); 
  }
  else 
  { 
  ?>
  
  		<p style="width:50%; border:1px solid black;
    		border-collapse: collapse;
    		background-color: #f1f1c1;">
  		<?php echo("Mail successfully sent !\n Check Your Email For further instructions.\n");
  		?>
  		</p>
  		<?php
  }

}
else
	{
		echo 'invalid Emailid';
	}
}
?>

  </header>
    <form method="post" action="reset_pass1.php">
		<div class="input-group">
			<label>Enter Your Email-id To Reset Password</label>
			<input type="text" name="email">
		</div>
     <button type="submit" name="submit" class="btn">Send</button>
     <p>  <a href="login1.php">Back</a>
		</p>
    </form>
  </body>
</html>

