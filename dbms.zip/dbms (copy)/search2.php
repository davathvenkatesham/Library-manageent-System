<! to search students in the library>

<html>
	<head>
		<title>Search User</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
	
	
	<header>
			<ul>
				<li><a href='home1.php' >Home</a></li>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
	
	<?php include('server4.php'); ?>
	
		<div class ="header">
			<h2>Search Users in the Library</h2>
		</div>
		<form method="post" action="search2.php">
			<?php include("errors.php"); ?>
			<div>
				<p>Search By</p>
			</div>
			
			<select name="search_by">
				<option value="student_id">Student-id</option>
				<option value="name">Name</option>
			</select>
			
			<div class="input-group">
			<input type="text" name="searchby" >
		</div>
			
		<div class="input-group">
			<button type="submit" name="search2" class="btn">Search</button>
		</div>
		<p>  <a href="home1.php">Back to Home</a>
		</p>
		</form>
	</body>
</html>
