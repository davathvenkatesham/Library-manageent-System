<!connect to database to search users>


<!DOCTYPE html>
<html>
<head>
	<title>All Users</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
		<header>
			<ul>
				<li><a href='home1.php' >Home</a></li>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='duefines.php'>Due Fines</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
		
		
		

<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if($db->connect_error)
	{
		die("Connection Failed:" . $db->connect_error);
	}
	
	
		$sql="select * 
					from users";
					
				$result=$db->query($sql);
				?>
				<table style="background-color:#f1f1c1; width:100% ;">
					<tr>
    					<th>User-id</th>
    					<th>Name</th>
    					<th>Email</th>
    					<th>Contact</th>
    					<th>Action</th>
    					<th>Action</th>
  					</tr>
				
				<?php
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><a href="userprofile.php?username=<?php echo  $row["username"]?>"><?php echo  $row["username"]?></a></td>
        				<td><?php echo  $row["name"] ?> </td>
        				<td><?php echo  $row["email"] ?></td>
        				<td><?php echo  $row["contact"] ?></td>
        				<td><a href="contactuser.php?username=<?php echo $row["email"];?>">Contact</a></td>
        				<td><a href="deleteuser.php?username=<?php echo $row["username"];?>">Delete</a></td>
        				
        			</tr>
        			
        		<?php
   				}
				?>
			</table>	

</body>
</html>
