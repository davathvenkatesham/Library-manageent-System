		<div class="span12">
				<a href="http://mnit.ac.in/"><div style="float:left;padding:1% 0 0 0px;margin-left:7%;"><img src="MNIT.jpg" height="80" width="80"></div></a>

<div style="padding:20px 0 0 0;margin-left:37%;"><font size="30">CENTRAL LIBRARY</font></div>

<div style="padding:10px 0 0 0;">MALAVIYA NATIONAL INSTITUTE OF TECHNOLOGY JAIPUR</div>


					<div class="alert alert-info"><Strong>Heads Up!</strong>&nbsp;Welcome to Library Of MNIT,jaipur. 
					
								
							<div class="pull-right">
								<i class="icon-calendar icon-large"></i>
								<?php
								$Today = date('y:m:d');
								$new = date('l, F d, Y', strtotime($Today));
								echo $new;
								?>
							</div>
					</div>
				
					
				</div>
