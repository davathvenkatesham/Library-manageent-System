<! connect to database to display all Books>

<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $db->connect_error);
		}
	
	
	
	
			$sql="select * 
					from books";

				$result=$db->query($sql);
				if($result->num_rows > 0)
				{
					while($row = $result->fetch_assoc()) 
					{
        				echo "Book-id: " . $row["book_id"]. ",Title: " . $row["title"]. ",Author: " . $row["author"]. ",Publisher: ". $row["publisher"]. ",Category: ". $row["category"]. ",Rental-Price: ". $row["author"].",Status: ". $row["status"]. "<br>";
        			
   				}
				}
				else
				{
					echo "no result found";
				}

?>



