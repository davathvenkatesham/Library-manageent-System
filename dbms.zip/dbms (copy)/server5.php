<!connect to database to see issued Books>
<?php include('server.php');?>
<html>
<head>
	<title>Issued Books</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
	<header>
				<ul>
				<li><a href='home.php'>Home</a></li>
				<li><a href='search.php'>Search Book</a></li>
				<li><a href="server5.php?username=<?php echo $_SESSION['username'];?>">See Issued Books</a></li>
				<li><a href='feedback.php?username=<?php echo $_SESSION['username'];?>'>Give Feedback</a></li>
				<li><a href='fine.php?username=<?php echo $_SESSION['username'];?>'>My Fines</a></li>
				<li><a href='login.php'>Logout</a></li>
			</ul>
		</header>
<?php
	
	
	$db=mysqli_connect('localhost','root','','library');
	if($db->connect_error)
	{
		die("Connection Failed:" . $db->connect_error);
	}
	
		$username=$_GET['username'];
		if(!empty($username))
		{
				$sql="select *
					from issued natural join books
					where username='$username'";
					
				$result=$db->query($sql);
					?>
					<table style="width:100%">
					<caption style="border:1px solid #80C4DE;
										border-radius:10px 0px 10px 0px;
										background:#5F9EAB;width:100%;
										height:50px;
										font-size:300%;">Issued Books</caption>
					<tr>
    					
    					<th>Book-id</th> 
    					<th>Title</th>
    					<th>Issue-Date</th>
    					<th>return-Date</th>
  					</tr>
					<?php
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				
        				<td><?php echo  $row["book_id"] ?> </td>
        				<td><?php echo  $row["title"] ?></td>
        				<td><?php echo  $row["issuedate"]?></td>
        				<td><?php echo  $row["returndate"]?></td>
        			</tr>
        			<?php
   				}
   				?>
   				</table>	
		<?php	
		
	}
?>
</body>
</html>
