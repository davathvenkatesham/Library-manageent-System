<?php include('header.php'); ?>
<?php include('navbar.php'); ?>

<?php
	$id=substr($_GET['id'],1,-1);
	$db=mysqli_connect('localhost','root','','library');
	
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $db->connect_error);
		}
	
			$sql="select * 
					from books
					where category='$id'";

				$result=$db->query($sql);
					
					?>
 
				<table style="background-color:#f1f1c1; width:100% ;margin-top:45px">
					<tr>
    					<th>Title</th> 
    					<th>Author</th>
    					<th>Publisher</th>
    					<th>Rental-Price</th>
    					<th>Count</th>
  					</tr>
					
				<?php
				
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["title"]?></td>
        				<td><?php echo  $row["author"]?></td>
        				<td><?php echo  $row["publisher"]?></td>
        				<td><?php echo  $row["price"]?></td>
        				<td><?php echo  $row["count"]?></td>
        			</tr>
        			
        		<?php
   				}
				
				?>
			</table>	

</body>
</html>
