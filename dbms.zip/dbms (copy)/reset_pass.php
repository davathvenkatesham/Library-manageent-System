<html>
	<head>
	<title>Forgot Password</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  	
  		<header>
		
<?php
$servername='localhost';
$username='root';
$password='';
$dbname = 'library';
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn)
{
die('Could not Connect My Sql:' .mysql_error());
}

session_start();


if(isset($_POST['submit']))
{
$email = $_POST['email'];
$result = mysqli_query($conn,"SELECT * FROM users where email='$email'");
$row = mysqli_fetch_assoc($result);
$fetch_email=$row['email'];
$username2=$row['username'];


if($email==$fetch_email)
{

$dpassword =rand(100001,999999);
$dpassword2=md5($dpassword);
mysqli_query($conn,"UPDATE forget SET  dpassword='$dpassword2' where username='$username2'");
require_once "Mail.php"; 
$from = "parvatjakhar@gmail.com"; 
$to = $email; 
$host = "ssl://smtp.gmail.com"; 
$port = "465"; 
$username = 'parvatjakhar@gmail.com';
 $password = 'Parvat@1';
 $subject = "Forgot Password"; 
 $body = "Your OTP is ".$dpassword."\nSEnter this OTP and Reset Password\n Regards \n MNIT LIBRARY"; 
 $headers = array ('From' => $from, 'To' => $to,'Subject' => $subject);
  $smtp = Mail::factory('smtp', array ('host' => $host, 'port' => $port, 'auth' => true, 'username' => $username, 'password' => $password));
  $mail = $smtp->send($to, $headers, $body); 
  if (PEAR::isError($mail)) 
  {
  		echo($mail->getMessage()); 
  }
  else 
  {

  		?>
  		<p style="padding:10px;
		font-size:15px;
		color:white;
		background:#5F9EAB;
		border:none;
		border-radius:5px;">
  		<?php echo("Mail sent successfully!\n");
  		
  		?>
  		<br>
  		
  		<a href="loginotp.php?username=<?php echo $username2;?>">Enter OTP</a>
  		</p>
  		
  		<?php
  		
  }

}
else
	{
		echo 'invalid Emailid';
	}
}
?>

  </header>
    <form method="post" action="reset_pass.php">
		<div class="input-group">
			<label>Enter Your Email-id To Reset Password</label>
			<input type="text" name="email">
		</div>
     <button type="submit" name="submit" class="btn">Send OTP</button>
     <p>  <a href="login.php">Back</a>
		</p>
    </form>
  </body>
</html>

