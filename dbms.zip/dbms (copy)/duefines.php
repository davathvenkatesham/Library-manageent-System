<!for student Log in>

<!DOCTYPE html>
<html>
<head>
	<title>Due Fines</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<header>
			<ul>
				<li><a href='home1.php' >Home</a></li>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Applied Requests</a></li>
				<li><a href='userfeedbacks.php'>Feedbacks</a></li>
				<li><a href='login1.php'>Logout</a></li>
				
			</ul>
		</header>
</body>
</html>
<?php
  
	$db=mysqli_connect('localhost','root','','library');
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $conn->connect_error);
		}
		{
		
		?>
		<table>
						<tr>
							<td>User_ID</td>
							<td>Total Fine</td>
							<td>Action</td>
						</tr>
		<?php
		
			$sql="SELECT * from fine where fine > 0";
					$result=$db->query($sql);
					while($row = $result->fetch_assoc()) 
					{
					$fine=$row["fine"];
					$username=$row["username"];
					?>
						<tr>
							<td><?php echo $username;?></td>
							<td><?php echo $fine;?></td>
							<td><a href="clearfine.php?username=<?php echo $username?>">Clear</a></td>
						</tr>
					</table>
					
					<?php
					}
		}
?>

