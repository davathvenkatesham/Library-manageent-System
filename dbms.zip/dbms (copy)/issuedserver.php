<!connect to database to see issued Books>
<html>
<head>
	<title>Issued Books</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>

<?php
	include('server.php');

	$db=mysqli_connect('localhost','root','','library');
	if($db->connect_error)
	{
		die("Connection Failed:" . $db->connect_error);
	}
	if(isset($_POST['issued']))
	{
		$username=mysql_real_escape_string($_POST['username']);
		
		
				$sql="select *
					from issued natural join books
					where username='$username'";
					
				$result=$db->query($sql);
					?>
					<table style="width:100%">
					<caption style="border:1px solid #80C4DE;
										border-radius:10px 0px 10px 0px;
										background:#5F9EAB;width:100%;
										height:50px;
										font-size:300%;">Issued Books</caption>
					<tr>
    					<th>User-id</th>
    					<th>Book-id</th> 
    					<th>Title</th>
    					<th>Issue-Date</th>
    					<th>return-Date</th>
    					<th>Action</th>
  					</tr>
					<?php
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["username"]?></td>
        				<td><?php echo  $row["book_id"] ?> </td>
        				<td><?php echo  $row["title"] ?></td>
        				<td><?php echo  $row["issuedate"]?></td>
        				<td><?php echo  $row["returndate"]?></td>
        				<td><a href="returnserver.php?book_id=<?php echo $row["book_id"];?>&amp;username=<?php echo  $row["username"];?> ">Return</a></td>				  
        			</tr>
        			</tr>
        			<?php
   				}
   				?>
   				</table>	
		<?php	
		
	
	}
	else if(isset($_GET['username']))
	{
		$username=($_GET['username']);
		
		
				$sql="select *
					from issued natural join books
					where username='$username'";
					
				$result=$db->query($sql);
					?>
					<table style="width:100%">
					<caption style="border:1px solid #80C4DE;
										border-radius:10px 0px 10px 0px;
										background:#5F9EAB;width:100%;
										height:50px;
										font-size:300%;">Issued Books</caption>
					<tr>
    					<th>User-id</th>
    					<th>Book-id</th> 
    					<th>Title</th>
    					<th>Issue-Date</th>
    					<th>return-Date</th>
    					<th>Action</th>
  					</tr>
					<?php
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["username"]?></td>
        				<td><?php echo  $row["book_id"] ?> </td>
        				<td><?php echo  $row["title"] ?></td>
        				<td><?php echo  $row["issuedate"]?></td>
        				<td><?php echo  $row["returndate"]?></td>
        				<td><a href="returnserver.php?book_id=<?php echo $row["book_id"];?>&amp;username=<?php echo  $row["username"];?> ">Return</a></td>				  
        			</tr>
        			</tr>
        			<?php
   				}
   				?>
   				</table>	
		<?php	
		
	
	}
	else
	{
		$sql="select *
					from issued natural join books
					";
					
				$result=$db->query($sql);
					?>
					<table style="width:100%">
					<caption style="border:1px solid #80C4DE;
										border-radius:10px 0px 10px 0px;
										background:#5F9EAB;width:100%;
										height:50px;
										font-size:300%;">Issued Books</caption>
					<tr>
    					<th>User-id</th>
    					<th>Book-id</th> 
    					<th>Title</th>
    					<th>Issue-Date</th>
    					<th>return-Date</th>
    					<th>Action</th>
  					</tr>
					<?php
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["username"]?></td>
        				<td><?php echo  $row["book_id"] ?> </td>
        				<td><?php echo  $row["title"] ?></td>
        				<td><?php echo  $row["issuedate"]?></td>
        				<td><?php echo  $row["returndate"]?></td>
        				<td><a href="returnserver.php?book_id=<?php echo $row["book_id"];?>&amp;username=<?php echo  $row["username"];?> ">Return</a></td>
        													  
        			</tr>
        			<?php
   				}
   				?>
   				</table>	
		<?php	
	}
?>
</body>
</html>
