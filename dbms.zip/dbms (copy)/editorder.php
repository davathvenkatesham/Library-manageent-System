<!admin home page>
<!DOCTYPE html>




<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<header>
			<ul>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Issue Requests</a></li>
				<li><a href='duefines.php'>Due Fines</a></li>
				<li><a href='orders.php'>Orders</a></li>
				<li><a href='userfeedbacks.php'>Feedbacks</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
		<?php include('changeorderserver.php'); ?>	
		<div class ="header">
			<h2>Edit Order</h2>
		</div>
	<form method="post" action="editorder.php" >
		<select name=username>
			<option value='<?php echo $_GET['orderno'];?>' ></option>
		</select>
		
		<div class="input-group">
			<label>Description</label>
			<input type="text" name="name">
		</div>
		<div class="input-group">
			<button type="submit" name="place" class="btn">Change</button>
		</div>
	</form>
				
</body>
</html>










