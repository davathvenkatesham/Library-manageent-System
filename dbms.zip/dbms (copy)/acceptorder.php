<!admin home page>
<!DOCTYPE html>
<?php include('sserver2.php');?>
<html>
<head>
	<title>Orders</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
		
		<header>
			<ul>
				<li><a href='home2.php'>Home</a></li>
				<li><a href='orders2.php'>New Orders</a></li>
				<li><a href='login2.php'>Logout</a></li>
			</ul>
		</header>
		
		<?php
		$order_no=$_GET['orderno'];
		$username=$_SESSION['username'];
		$date=date('Y-m-d');
		$db=mysqli_connect('localhost','root','','library');
		if($db->connect_error)
			{
				die("Connection Failed:" . $db->connect_error);
			}
		$query="insert into accepted(username,order_no,date) values ('$username','$order_no','$date')";
		if(mysqli_query($db,$query))
		{
			echo "Order Accepted Successfully";
		}
		
		
		
?>
				
</body>
</html>










