<?php
		$errors=array();
		if(isset($_POST['update']))
		{

			$db=mysqli_connect('localhost','root','','library');
		if ($db->connect_error)
	 	{
    		die("Connection failed: " . $conn->connect_error);
		}
		$email=mysql_real_escape_string($_POST['email']);
		$username=mysql_real_escape_string($_POST['username']);
		if(empty($email))
		{
			array_push($errors,"Enter Email ID");
		}

		if(count($errors)==0)
		{
			echo $username;
			$sql="UPDATE users SET email='$email' where username='$username'";
			mysqli_query($db,$sql);
			?>
			
			<p>
			<?php echo "Email updated Successful.\n";?>
			</p>
			<a href="profile.php?username=<?php echo $username?>">Back</a>
			<?php
		}
	}
			
?>
	
