<!connect to database to search users>


<!DOCTYPE html>
<html>
<head>
	<title>Orders</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
		<header>
			<ul>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Issue Requests</a></li>
				<li><a href='duefines.php'>Due Fines</a></li>
				<li><a href='orders.php'>Orders</a></li>
				<li><a href='userfeedbacks.php'>Feedbacks</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
		
		
		

<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if($db->connect_error)
	{
		die("Connection Failed:" . $db->connect_error);
	}
	
	
		$sql="select *
					from orders";
					
				$result=$db->query($sql);
				?>
				<table style="background-color:#f1f1c1; width:100% ;">
					<tr>
    					<th>Order-id</th>
    					<th>Description</th>
    					<th>Date</th>
    					<th>Action</th>
    					<th>Action</th>
  					</tr>
				
				<?php
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["order_no"] ?> </td>
        				<td><?php echo  $row["description"] ?></td>
        				<td><?php echo  $row["date"] ?></td>
        				<td><a href="editorder.php?orderno=<?php echo $row["order_no"];?>">Change</a></td>
        				<td><a href="deleteorder.php?username=<?php echo $row["order_no"];?>">Delete</a></td>
        			</tr>
        			
        		<?php
   				}
				?>
			</table>	
			<p><a href="placeorder.php">Place New Order</a></p>
</body>
</html>
