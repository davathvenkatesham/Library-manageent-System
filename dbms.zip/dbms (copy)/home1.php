<!admin home page>
<?php include('server.php');?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
	
	
</head>
<body>
		
		<header>
			<ul>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Issue Requests</a></li>
				<li><a href='duefines.php'>Due Fines</a></li>
				<li><a href='orders.php'>Orders</a></li>
				<li><a href='userfeedbacks.php'>Feedbacks</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
		
		
		<img class="image" src="https://upload.wikimedia.org/wikipedia/en/b/b7/Mnit_logo.png" style="width:200px;height:200px;" alt="MNIT LOGO">
		
		<img class="image2" src="https://img.freepik.com/free-vector/library-bookshelf_23-2147502675.jpg?size=338&ext=jpg" alt="Library Image" style="width:200px;height:200px;" align=right>
		
		
		
		
		<?php 
		$db=mysqli_connect('localhost','root','','library');
		?>
		<table style="background-color:#f1f1c1; width:50% ;margin-top:-205px; margin-left: auto;
margin-right: auto;">
			<?php
					$username='admin';
					$query="select * from admin where admin_id='$username'";
					$result=mysqli_query($db,$query);
					$row = $result->fetch_assoc()
					?>
					<tr>
        				<td>Admin-Id</td>
        				<td><?php echo  $row["admin_id"];?></td>
        			</tr>
        			<tr>
        				<td>Name</td>
        				<td><?php echo  $row["name"];?></td>
        			</tr>
        			<tr>
        				<td>Email</td>
        				<td><?php echo  $row["email"];?></td>
        			</tr>
        			<tr>
        				<td>Contact</td>
        				<td><?php echo  $row["contact"];?></td>
        			</tr>
        			<tr>
        				<td>Designation</td>
        				<td><?php echo  $row["position"];?></td>
        			</tr>
			</table>	
		
		<div class="content">
			<?php if(isset($_SESSION['success'])):?>
				<div class="error success">
					<h3>
						<?php
							echo $_SESSION["success"];
							unset($_SESSION["success"]); 
						?>
					</h3>
				</div>
			<?php endif ?>
			
			<?php if(isset($_SESSION['username'])):?>
				
				
				
			<?php endif ?>
			
		</div>
		
		<?php
		if(isset($_POST['newbook']))
		{
			header('location:newbook.php');
		}
		?>
		<?php
		if(isset($_POST['logout']))
		{
			header('location:login1.php');
		}
		?>
		
		
		
		
</body>
</html>
