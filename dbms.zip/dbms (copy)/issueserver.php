<!connect to database to issue Book>
<?php 
		?>
<html>
<head>
	<title>Issue Book</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
			<ul>
				<li><a href='home1.php' >Home</a></li>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Apply Requests</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
		
		<form method="post" action="issueserver.php?book_id=<?php echo $_GET['book_id'];?>&amp;username=<?php echo  $_GET['username'];?>">
			<div class="input-group">
				<label>Return Date</label>
				<input type="date" name="returndate">
			</div>
			<div class="input-group">
			<button type="submit" name="issue" class="btn">Issue</button>
		</div>
		</form>
		
<?php
if(isset($_POST['issue']))
{
	include('server.php');
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if($db->connect_error)
	{
		die("Connection Failed:" . $db->connect_error);
	}
	if(isset($_GET['book_id']))
	{	
		$bookid=$_GET['book_id'];
		$username=$_GET['username'];
		$issuedate=date("Y-m-d"); 
		$returndate=mysql_real_escape_string($_POST['returndate']);

				$sql="select count from books where book_id=$bookid";
				$result=$db->query($sql);
				$row = $result->fetch_assoc();
				$count=$row["count"];
				 --$count;
				
				if($count==-1)
				{
					echo "No Books available";
					$message='No Books Available For Book-Id ='.$bookid ;
					date_default_timezone_set('Asia/Kolkata');
					$time=date("h:i:a");
					$sql="INSERT INTO notification(username,notification,date,time)
							VALUES ('$username','$message','$issuedate','$time')";	
							mysqli_query($db,$sql);
				}
				else
				{
					$sql="INSERT INTO issued(username,book_id,issuedate,returndate)
						VALUES ('$username','$bookid','$issuedate','$returndate')";	
					mysqli_query($db,$sql);
					
					$message='Book issued By Admin Collect From Library Book-Id ='.$bookid.' return date='.$returndate;
					date_default_timezone_set('Asia/Kolkata');
					$time=date("h:i:a");
					$sql="INSERT INTO notification(username,notification,date,time)
							VALUES ('$username','$message','$issuedate','$time')";	
							mysqli_query($db,$sql);
					
					
					$sql="update books 
					set count='$count'
					where book_id='$bookid'";
					mysqli_query($db,$sql);
				
				
				$sql="DELETE from applied
						where book_id=$bookid and username=$username";	
					if(mysqli_query($db,$sql))
					{
						echo "Book Issued Successfully";
					}
					else
					{
						echo "Error ! Book can't Be Issued. ";
					}
				
				}

	}
}
?>
</body>
</html>
