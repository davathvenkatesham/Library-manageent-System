<html>
<head>
	<title>User Profile</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<header>
			<ul>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Applied Requests</a></li>
				<li><a href='duefines.php'>Due Fines</a></li>
				<li><a href='userfeedbacks.php'>Feedbacks</a></li>
				<li><a href='login1.php'>Logout</a></li>
				
			</ul>
		</header>
<?php
	$username=$_GET['username'];
	
	
		$db=mysqli_connect('localhost','root','','library');
		?>
		<table style="background-color:#f1f1c1; width:50% ; margin-left: auto;
margin-right: auto;">
			<?php
					$query="select * from users natural join fine where username='$username'";
					$result=mysqli_query($db,$query);
					$row = $result->fetch_assoc()
					?>
					<tr>
        				<td>User-Id</td>
        				<td><?php echo  $row["username"];?></td>
        			</tr>
        			<tr>
        				<td>Name</td>
        				<td><?php echo  $row["name"];?></td>
        			</tr>
        			<tr>
        				<td>Email</td>
        				<td><?php echo  $row["email"];?></td>
        			</tr>
        			<tr>
        				<td>Contact</td>
        				<td><?php echo  $row["contact"];?></td>
        			</tr>
        			<tr>
        				<td>Due Fines</td>
        				<td><?php echo  $row["fine"];?></td>
        			</tr>
        			<tr>
        				<td><a href="clearfine.php?username=<?php echo $username?>">Clear Fines</a></td>
        				<td> </td>
        			</tr>
        			<tr>
        				<td><a href="issuedserver.php?username=<?php echo $username;?>">Issued Books</td>
        				<td> </td>
        			</tr>
			</table>
	<?php
	
?>
</body>
