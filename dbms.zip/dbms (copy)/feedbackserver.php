<!//for student data entry>
<?php
  
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $conn->connect_error);
		}
	//if register is clicked
	if(isset($_POST['feedback']))
	{
		$username=$_GET['username'];
		$feedback=mysql_real_escape_string($_POST['feedback']);
		

		
		if(count($errors)==0)
		{
			$sql="INSERT INTO users(username,feedback)
					VALUES ('$username','$feedback')";
			mysqli_query($db,$sql);
		}
	}
?>
