<!for admin Log in>

<?php include('server1.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
</head>
<body>
	<header>
			<h1 style="margin-top:-15px;">Welcome to LiBRARY</h1>
			
		</header>
		
		<div class ="header">
			<h2>Admin Login</h2>
		</div>
		
	<form method="post" action="login1.php">
	<?php include("errors.php"); ?>
		<div class="input-group">
			<label>Username</label>
			<input type="text" name="admin_id">
		</div>
		
		<div class="input-group">
			<label>Password</label>
			<input type="password" name="password">
		</div>
		
		<div class="input-group">
			<button type="submit" name="Login1" class="btn">Login</button>
			<button type="submit" name="back" class="btn">Back</button>
		</div>
		<p> <a href="reset_pass1.php">Forgot Password</a>
		</p>
	</form>
	
	<!back to index>
	
		<?php
		if(isset($_POST['back']))
		{
			header('location:index1.php');
		}
		?>
	
	
</body>
</html>
