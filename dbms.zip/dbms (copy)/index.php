
<?php include('header.php'); ?>
<?php include('navbar.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">
					<?php include('head.php'); ?>
				<div class="span2">
					<?php include('sidebar.php'); ?>
				</div>
				<div class="span10">
					<?php include('slider.php'); ?>
				</div>
			
				<div class="span2">
				<h4></h4>
			
				</div>
				<div class="span10">
				
				
				<?php include('thumbnail.php'); ?>
				<table width="450" style="margin: 0pt auto;">
	
	<thead><tr><th colspan="3" style="text-align: center;"><h3>LIBRARY HOURS</h3></th></tr></thead>
	<tbody>
	<tr>
	<td colspan="3"></td>
	</tr>
	<tr>
	<td>Monday and Tuesday</td>
	<td>NO NOON</td>
	<td>8:00 a.m. to 7:00 p.m.</td>
	</tr>
	<tr>
	<td>Wednesday to Friday</td>
	<td>BREAK</td>
	<td>8:00 a.m. to 6:30 p.m.</td>
	</tr>
	</tbody>
	</table>
					
					<div class="text_content">
					<div class="abc">
					
					<h4>Vision</h4>
					<hr>
					<p>
					By 2018.  Library Of Malaviya National Institute Of Technology is a center of learning where stackholders are conscientiously involved in loning holistic 
					individuals committed to positively respond to the needs of the school, community and the country.
					</p>
					<hr>
					<h4>Mission</h4>
					<hr>
					<p>
					To nurture students to become productive responsible citizens through the assistance of service - 
					oriented and highly competent internal and external stakeholders working in a harmonious relationship.
					</p>
					<hr>
					</div>
					</div>
					<!-- end content -->
				
				
				</div>
			
			</div>
		</div>
    </div>
<?php include('footer.php') ?>
