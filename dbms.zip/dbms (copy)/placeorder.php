
<html>
<head>
	<title>New order</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
	<style>
	body
		{
			border: 10px solid #5F9EAB;
			border-radius:	10px 10px 10px 10px;
		}
	</style>
	
	
</head>
<body>
	
		<header>
			<ul>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Issue Requests</a></li>
				<li><a href='duefines.php'>Due Fines</a></li>
				<li><a href='orders.php'>Orders</a></li>
				<li><a href='userfeedbacks.php'>Feedbacks</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
	
	<?php
$errors=array();
if(isset($_POST['place']))
	{
	
		$db=mysqli_connect('localhost','root','','library');
		if($db->connect_error)
			{
				die("Connection Failed:" . $db->connect_error);
			}
		$username=mysql_real_escape_string($_POST['username']);
		$desc=mysql_real_escape_string($_POST['name']);
		$date=date('Y-m-d');
		
		
		//ensure form fields are filled correctly
		if(empty($username))
		{
			array_push($errors,"Order No Required");
		}
		if(empty($username))
		{
			array_push($errors,"Please Enter Order Description");
		}
		
		//if there is already username exist.
		
		$query="select * from orders where order_no='$username'";
		$result=mysqli_query($db,$query);
		
		if(mysqli_num_rows($result)==1)
		{
			array_push($errors,"Order No. exist");
		}

		// if there is no error,save user to database;
		
		if(count($errors)==0)
		{
			$sql="INSERT INTO orders(order_no,description,date)
					VALUES ('$username','$desc','$date')";
			mysqli_query($db,$sql);
			
			echo "Order Placed Successfully\n";
		}
			
	}

?>
	

		
		<div class ="header">
			<h2>Place Order</h2>
		</div>
		
	<form method="post" action="placeorder.php" >
	<?php include('errors.php'); ?>
		<div class="input-group">
			<label>Order-No</label>
			<input type="text" name="username">
		</div>
		
		<div class="input-group">
			<label>Description</label>
			<input type="text" name="name">
		</div>
		
		
		<div class="input-group">
			<button type="submit" name="place" class="btn">Place</button>
		</div>

	</form>
</body>
</html>
