<!admin home page>
<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	
	
	
</head>
<body>
		
		<header>
			<ul>
				<li><a href='search1.php' >Search Book</a></li>
				<li><a href='allbooks.php'>All Books</a></li>
				<li><a href='allusers.php'>All Users</a></li>
				<li><a href='newbook.php'>Enter New Book Data</a></li>
				<li><a href='issued1.php' >See Issued Books</a></li>
				<li><a href='search2.php'>Search Student</a></li>
				<li><a href='applied.php'>Issue Requests</a></li>
				<li><a href='duefines.php'>Due Fines</a></li>
				<li><a href='orders.php'>Orders</a></li>
				<li><a href='userfeedbacks.php'>Feedbacks</a></li>
				<li><a href='login1.php'>Logout</a></li>
			</ul>
		</header>
		<?php
		$order_no=$_GET['username'];
		$db=mysqli_connect('localhost','root','','library');
		if($db->connect_error)
			{
				die("Connection Failed:" . $db->connect_error);
			}
		$query="delete from orders where order_no='$order_no'";
		if(mysqli_query($db,$query))
		{
			echo "Order Deleted Successfully";
		}
		
?>
				
</body>
</html>










