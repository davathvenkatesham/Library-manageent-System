<! connect to database to search Books>
<html>
<head>
</head>
<body>
<?php
	$errors=array();
	$db=mysqli_connect('localhost','root','','library');
	
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $db->connect_error);
		}
	
	//if search is clicked
	if(isset($_POST['search'])||isset($_POST['search1']))
	{
		
		$searchby=mysql_real_escape_string($_POST['searchby']);
		$search_by=mysql_real_escape_string($_POST['search_by']);
		
		//ensure atleast one field is filled correctly
		if(!empty($searchby))
		{
			if($search_by=='book_id')
			{
				$sql="select * 
					from books
					where book_id='$searchby'";
					
				$result=$db->query($sql);
				if($result->num_rows > 0)
				{
				?>
				<table style="width:100%;background-color:#f1f1c1;">
					<tr>
    					<th>Book-id</th>
    					<th>Title</th> 
    					<th>Author</th>
    					<th>Publisher</th>
    					<th>Category</th>
    					<th>Rental-Price</th>
    					<th>Count</th>
    					<th>Action</th>
    					<th>Action</th>
  					</tr>
				
				<?php
				
					while($row = $result->fetch_assoc()) 
					{
					?>
					
					<tr>
        				<td><?php echo  $row["book_id"]?></td>
        				<td><?php echo  $row["title"]?></td>
        				<td><?php echo  $row["author"]?></td>
        				<td><?php echo  $row["publisher"]?></td>
        				<td><?php echo  $row["category"]?></td>
        				<td><?php echo  $row["price"]?></td>
        				<td><?php echo  $row["count"]?></td>
						<td><a href="editbook.php?book_id=<?php echo $row["book_id"];?>">Edit Details</a></td>
        				<td><a href="deletebook.php?book_id=<?php echo $row["book_id"];?>">Delete</a></td>
        			</tr>
        			
        		<?php
   				}
				
				?>
			</table>	

<?php
				}
				else
				{
					echo "no result found";
				}
			}
			else if($search_by=='title')
			{$sql="select * 
					from books
					where title='$searchby'";
					
				$result=$db->query($sql);
				if($result->num_rows > 0)
				{
				?>
				<table style="width:100%">
					<tr>
    					<th>Book-id</th>
    					<th>Title</th> 
    					<th>Author</th>
    					<th>Publisher</th>
    					<th>Category</th>
    					<th>Rental-Price</th>
    					<th>Count</th>
    					<th>Action</th>
  					</tr>
				
				<?php
				
					while($row = $result->fetch_assoc()) 
					{
					?>
					
					<tr>
        				<td><?php echo  $row["book_id"]?></td>
        				<td><?php echo  $row["title"]?></td>
        				<td><?php echo  $row["author"]?></td>
        				<td><?php echo  $row["publisher"]?></td>
        				<td><?php echo  $row["category"]?></td>
        				<td><?php echo  $row["price"]?></td>
        				<td><?php echo  $row["count"]?></td>
        				<td><a href="applyserver.php?book_id=<?php echo $row["book_id"]?>">Apply</a></td>
        			</tr>
        			
        			
        		<?php
   				}
				
				?>
			</table>	

<?php
				}
				else
				{
					echo "no result found";
				}
			}
			else if($search_by=='author')
			{
				$sql="select * 
					from books
					where author='$searchby'";
					
				$result=$db->query($sql);
				if($result->num_rows > 0)
				{
				?>
				<table style="width:100%">
					<tr>
    					<th>Book-id</th>
    					<th>Title</th> 
    					<th>Author</th>
    					<th>Publisher</th>
    					<th>Category</th>
    					<th>Rental-Price</th>
    					<th>Status</th>
    					<th>Action</th>
  					</tr>
				
				<?php
				
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["book_id"]?></td>
        				<td><?php echo  $row["title"]?></td>
        				<td><?php echo  $row["author"]?></td>
        				<td><?php echo  $row["publisher"]?></td>
        				<td><?php echo  $row["category"]?></td>
        				<td><?php echo  $row["price"]?></td>
        				<td><?php echo  $row["count"]?></td>
        				<td><a href="applyserver.php?book_id=<?php echo $row["book_id"]?>">Apply</a></td>
        				
        			</tr>
        			
        		<?php
   				}
				
				?>
			</table>	

<?php
				}
				else
				{
					echo "no result found";
				}
			}
			else if($search_by=='publisher')
			{
				$sql="select * 
					from books
					where publisher='$searchby'";
					
				$result=$db->query($sql);
				if($result->num_rows > 0)
				{
				?>
				<table style="width:100%">
					<tr>
    					<th>Book-id</th>
    					<th>Title</th> 
    					<th>Author</th>
    					<th>Publisher</th>
    					<th>Category</th>
    					<th>Rental-Price</th>
    					<th>count</th>
    					<th>Action</th>
  					</tr>
				
				<?php
				
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["book_id"]?></td>
        				<td><?php echo  $row["title"]?></td>
        				<td><?php echo  $row["author"]?></td>
        				<td><?php echo  $row["publisher"]?></td>
        				<td><?php echo  $row["category"]?></td>
        				<td><?php echo  $row["price"]?></td>
        				<td><?php echo  $row["count"]?></td>
        				<td><a href="applyserver.php?book_id=<?php echo $row["book_id"]?>">Apply</a></td>
        				
        			</tr>
        			
        		<?php
   				}
				
				?>
			</table>	

<?php
				}
				else
				{
					echo "no result found";
				}
			}
			else
			{
				$sql="select * 
					from books
					where category='$searchby'";
					
				$result=$db->query($sql);
				if($result->num_rows > 0)
				{
				?>
				<table style="width:100%">
					<tr>
    					<th>Book-id</th>
    					<th>Title</th> 
    					<th>Author</th>
    					<th>Publisher</th>
    					<th>Category</th>
    					<th>Rental-Price</th>
    					<th>Count</th>
    					<th>Action</th>
  					</tr>
				
				<?php
				
					while($row = $result->fetch_assoc()) 
					{
					?>
					<tr>
        				<td><?php echo  $row["book_id"]?></td>
        				<td><?php echo  $row["title"]?></td>
        				<td><?php echo  $row["author"]?></td>
        				<td><?php echo  $row["publisher"]?></td>
        				<td><?php echo  $row["category"]?></td>
        				<td><?php echo  $row["price"]?></td>
        				<td><?php echo  $row["count"]?></td>
        				<td><a href="applyserver.php?book_id=<?php echo $row["book_id"]?>">Apply</a></td>
        				
        			</tr>
        			
        		<?php
   				}
				
				?>
			</table>	

<?php
				}
				else
				{
					echo "no result found";
				}
			}
			
		}
		
		else
		{
			array_push($errors,"Please fill the field");
		}
		
	}
?>

</body>
</html>
