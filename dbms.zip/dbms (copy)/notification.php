<!for student Log in>

<!DOCTYPE html>
<?php $username=$_GET['username'];?>
<html>
<head>
	<title>Notifications</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
		<header>
			<ul>
				<li><a href='home.php'>Home</a></li>
				<li><a href='search.php'>Search Book</a></li>
				<li><a href='server5.php'>See Issued Books</a></li>
				<li><a href='login.php'>Logout</a></li>
			</ul>
		</header>

</body>
</html>
<!//for student data entry>
<?php
  
	$db=mysqli_connect('localhost','root','','library');
	if ($db->connect_error)
	 	{
    		die("Connection failed: " . $conn->connect_error);
		}
		{
			$sql="SELECT * from notification
					where username='$username'";
					$result=$db->query($sql);
					?>
					
					<table>
						<tr>
							<td>Notificatiion Date</td>
							<td>Time</td>
							<td>Message</td>
						</tr>
					
					<?php
					while($row =$result->fetch_assoc())
					{
					$date=$row["date"];
					$time=$row["time"];
					$message=$row["notification"];
					?>
					
						<tr>
							<td><?php echo $date;?></td>
							<td><?php echo $time;?></td>
							<td><?php echo $message;?></td>
						</tr>
					
					
					<?php
					}
					?>
					<tr>
						<td><a href="clearnotification.php?username=<?php echo $username;?>">Clear Notifications</a></td>
						<td></td>
						<td></td>
					</tr>
					</table>
					
					<?php
		}
?>
